defmodule Project4part2Web.LayoutViewTest do
  use Project4part2Web.ConnCase, async: true
end
