defmodule Project4part2Web.PageViewTest do
  use Project4part2Web.ConnCase, async: true
end
