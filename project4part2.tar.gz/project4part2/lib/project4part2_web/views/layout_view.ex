defmodule Project4part2Web.LayoutView do
  use Project4part2Web, :view
end
