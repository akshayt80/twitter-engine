defmodule Project4part2Web.PageView do
  use Project4part2Web, :view
end
